package com.dicoding.githubusernavigationapi.networking

import com.dicoding.githubusernavigationapi.BuildConfig
import com.dicoding.githubusernavigationapi.model.DetailUserResponse
import com.dicoding.githubusernavigationapi.model.User
import com.dicoding.githubusernavigationapi.model.UserResponse
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
//    val mySuperScretKey = BuildConfig.KEY // eror

    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getSearchUsers(
        @Query("q") query: String
    ): Call<UserResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getUserDetail(
        @Path("username") username: String
    ): Call<DetailUserResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getFollowers(
        @Path("username") username: String
    ): Call<ArrayList<User>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getFollowing(
        @Path("username") username: String
    ): Call<ArrayList<User>>

}